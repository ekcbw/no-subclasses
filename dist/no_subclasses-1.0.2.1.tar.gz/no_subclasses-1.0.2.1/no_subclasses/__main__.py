from no_subclasses.safe_eval import safe_eval_shell

safe_eval_shell()